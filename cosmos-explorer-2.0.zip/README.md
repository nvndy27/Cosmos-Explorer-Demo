# Cosmos Explorer

Mở [cosmos-explorer/index.html](cosmos-explorer/index.html) bằng trình duyệt để sử dụng. Không cần cài đặt.

[Xem hướng dẫn](cosmos-explorer/README.md), [requirements](docs/REQUIREMENTS.md), [roadmap](docs/ROADMAP.md), [chính sách dữ liệu](docs/DATA_POLICY.md), [kiểm thử](docs/QA.md).
