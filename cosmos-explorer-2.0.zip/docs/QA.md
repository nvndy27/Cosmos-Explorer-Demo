# Kiểm chứng bản 2.0

## Đã chạy
- Kiểm tra cú pháp `catalog.js` và `app.js` bằng Node.
- 10 nhóm smoke: khởi động, toàn vẹn nguồn/ảnh, chọn và vẽ 21 hồ sơ, tìm không dấu/trống, lưu/lọc/trống, so sánh và trường hợp không áp dụng, ảnh lỗi, tạm dừng, bộ nhớ hỏng/reduced motion, tab ARIA.
- Đối chiếu trang nguồn bằng công cụ web; ghi rõ các trang hạn chế truy cập trong DATA_POLICY.md.

## Chưa xác nhận
Môi trường không cho mở máy chủ socket cục bộ; công cụ browser chặn file:// và sau đó từ chối yêu cầu truy cập theo chính sách phê duyệt. Vì vậy chưa có screenshot hay xác nhận bố cục, thực thi Canvas và tải ảnh trong trình duyệt thật. Smoke không thay thế browser e2e.

## Checklist thủ công
- [ ] Mở index.html ở Chrome/Firefox, không lỗi console.
- [ ] 1440×900, 820×1180, 390×844: không tràn ngang trang; thanh danh mục cuộn được.
- [ ] Chuyển đủ 7 nhóm, chọn tinh vân và hố đen, quan sát hình dạng riêng.
- [ ] Chuyển 4 ảnh quan sát, đọc ghi công, mở nguồn; thử mất mạng để kiểm tra dự phòng.
- [ ] Tab/Shift+Tab qua điều khiển, giữ focus trong hướng dẫn, Esc trả focus.
- [ ] Tìm “sao thuy”, Enter, thử kết quả rỗng.
- [ ] Lưu mục, tải lại, lọc Đã lưu trong từng nhóm.
- [ ] So sánh Trái Đất/Sao Mộc, hồ sơ hố đen không cho so sánh bán kính.
- [ ] Dừng chuyển động, thay tốc độ, bật lại; reduced motion mặc định dừng.
- [ ] Mở URL #sgr, tải lại đúng hồ sơ.
