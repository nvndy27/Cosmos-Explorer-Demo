# Requirements — Cosmos Explorer 2.0

## Mục tiêu bản sử dụng cục bộ
Người dùng phổ thông tiếng Việt khám phá các thiên thể đã xác nhận, đọc kiến thức có dẫn nguồn, phân biệt tư liệu thật và minh họa. Mở bằng trình duyệt, không cần tài khoản, API key hoặc cài công cụ build.

## Yêu cầu và tiêu chí chấp nhận
| Mã | Yêu cầu | Tiêu chí |
|---|---|---|
| F01 | Danh mục | 21 hồ sơ thuộc 7 nhóm; đủ 8 hành tinh, sao, thiên hà, tinh vân, hố đen |
| F02 | Tìm kiếm | Tìm toàn danh mục, hỗ trợ tiếng Việt không dấu; trạng thái không có kết quả; Enter chọn đầu tiên |
| F03 | Hồ sơ | Tổng quan, 4 thông số có nguồn, kiến thức, giới hạn quan sát, nguồn và nghiên cứu liên quan |
| F04 | Đồ họa | Hành tinh có chiếu sáng, vành đai Thổ, thiên hà hạt, đám mây tinh vân, hố đen minh họa |
| F05 | Phân loại hình | Mô hình luôn ghi minh họa; ảnh quan sát có ghi xử lý màu/tái dựng, tác giả và nguồn |
| F06 | Tương tác | Kéo dịch góc nhìn, phóng/thu/đặt lại, dừng/chạy, tốc độ, tiếp theo |
| F07 | Đã lưu | Lưu bằng localStorage; lọc theo nhóm; không lỗi khi lưu trữ bị cấm hoặc dữ liệu hỏng |
| F08 | So sánh | Chỉ so sánh bán kính có dữ liệu; không dùng khối lượng hố đen làm bán kính |
| F09 | Chia sẻ | Hash URL xác định hồ sơ, mở lại đúng mục |
| N01 | Responsive | Bố cục ba cột desktop, xếp dọc và cuộn danh mục ở mobile |
| N02 | Tiếp cận | Focus bàn phím, nhãn điều khiển, tab có ARIA, đóng/giữ focus hộp hướng dẫn, reduced motion |
| N03 | Khả dụng | Nội dung biên tập và Canvas chạy không mạng; ảnh ngoài lỗi có dự phòng đúng nhãn |
| N04 | Chất lượng | Kiểm tra cú pháp và smoke hành vi đạt; kiểm tra trình duyệt thực được ghi trạng thái trung thực |

## Phạm vi dữ liệu
Là thư viện tuyển chọn và ghi chú từ các nguồn gốc, không phải bản sao đầy đủ Gaia, dịch vụ API thời gian thực, công cụ dẫn đường bầu trời hoặc mô phỏng hấp dẫn. Các mục chưa có ảnh tích hợp vẫn có liên kết nguồn chính thức.
