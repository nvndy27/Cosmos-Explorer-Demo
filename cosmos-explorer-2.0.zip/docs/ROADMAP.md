# Roadmap

## Bản 2.0 — đã triển khai
- [x] Tách dữ liệu và nguồn khỏi logic giao diện.
- [x] Mở rộng từ 9 lên 21 hồ sơ, bổ sung tinh vân và hố đen.
- [x] Tra cứu NASA, NASA Exoplanet Archive, ESA Gaia DR3 và các bài báo liên quan.
- [x] Bổ sung hình minh họa hố đen, tinh vân và màu riêng cho các hành tinh.
- [x] Chế độ ảnh quan sát cho 4 mục, ghi công và giới hạn ảnh.
- [x] Nguồn cho thông số, nghiên cứu và ngày biên tập.
- [x] Giao diện responsive, tìm không dấu, lọc đã lưu và URL hồ sơ.
- [x] Xử lý ảnh lỗi, bộ nhớ hỏng, reduced motion, focus hộp thoại.
- [x] 10 nhóm kiểm tra hành vi bằng Node không cần dependency.

## Kiểm chứng trước phát hành công khai
- [ ] Kiểm tra trực quan Chrome/Firefox desktop và mobile, kiểm tra mạng/ảnh thật. Môi trường hiện tại chặn máy chủ socket và công cụ browser, nên chưa xác nhận bằng screenshot.
- [ ] Rà soát khả năng tiếp cận bằng trình đọc màn hình.

## 2.1 — tư liệu và biên tập
- Tải bản ảnh tối ưu về máy sau khi kiểm tra quyền và ghi công, bổ sung ảnh cho các hồ sơ còn thiếu.
- Mở rộng sao và ngoại hành tinh với reference theo từng phép đo, sai số, năm công bố và phương pháp.
- Thêm lịch kiểm tra liên kết, thay đổi danh mục và bảng ghi lịch sử cập nhật.

## 3.0 — dữ liệu có thể tái tạo
- Pipeline snapshot NASA Exoplanet Archive/TAP: lưu truy vấn, thời điểm, hệ đơn vị và tham chiếu gốc.
- Tập con Gaia DR3 có source_id, parallax/error, proper motion và quy tắc lọc; tách vị trí đo khỏi hiệu ứng nền.
- Chỉ thêm WebGL/3D sau khi có đo hiệu năng, fallback và kiểm chứng phép biến đổi tọa độ.
- Các giai đoạn 2.1/3.0 là hướng mở rộng, không phải chức năng đã hoàn thành.
