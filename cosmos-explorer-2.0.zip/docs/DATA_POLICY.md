# Dữ liệu và tư liệu khoa học

Ngày biên tập: 2026-10-21. `cosmos-explorer/catalog.js` là nguồn dữ liệu của ứng dụng. Trường `source` áp dụng cho hồ sơ và thông số; `references` và `papers` bổ sung nguồn quan sát/nghiên cứu; `reviewed` ghi ngày biên tập. Đây là bản ghi tuyển chọn, không tự cập nhật.

## Nguồn
- Hệ Mặt Trời: NASA Science, trang Facts theo từng đối tượng. Số liệu làm tròn; không dùng số vệ tinh hay thông số chưa kiểm chứng mới.
- TRAPPIST-1e: [NASA Exoplanet Archive](https://exoplanetarchive.ipac.caltech.edu/overview/TRAPPIST-1e), [NASA về Webb 2025](https://science.nasa.gov/missions/webb/nasa-webb-looks-at-earth-sized-habitable-zone-exoplanet-trappist-1-e/), [Gillon 2017](https://doi.org/10.1038/nature21360), [DREAMS 2025](https://arxiv.org/abs/2509.05414). Không khẳng định phát hiện sự sống, nước hay khí quyển. Trang Archive qua công cụ mở trực tiếp bị timeout; kết quả tìm kiếm Archive xác nhận chu kỳ ~6,1 ngày, bán kính ~0,92 Trái Đất và xác nhận quá cảnh năm 2017.
- Ngân Hà: [ESA Gaia](https://www.esa.int/Science_Exploration/Space_Science/Gaia), [nội dung DR3](https://www.cosmos.esa.int/web/gaia/dr3), [Gaia Collaboration 2023](https://doi.org/10.1051/0004-6361/202243940). 1,806 tỷ là số nguồn có độ sáng G trong DR3, không phải số ngôi sao ứng dụng dựng hoặc tổng số sao Ngân Hà. Trang Cosmos chặn truy cập trực tiếp qua công cụ (451), tóm tắt tìm kiếm nguồn chính thức được dùng để đối chiếu.
- M42, M1, M51: danh mục Hubble Messier của NASA.
- Sgr A*, M87*: ESO/EHT và bài báo EHT 2022/2019 được liên kết trong từng hồ sơ.

## Phân loại ảnh
| Mục | Tư liệu | Ghi công |
|---|---|---|
| Orion | VISTA hồng ngoại, ảnh quan sát gán màu | ESO/J. Emerson/VISTA; Cambridge Astronomical Survey Unit |
| M51 | Hubble ACS khả kiến, ảnh tổng hợp bộ lọc | NASA, ESA, M. Regan và B. Whitmore (STScI), R. Chandar (University of Toledo), S. Beckwith (STScI), Hubble Heritage Team (STScI/AURA) |
| Sgr A* | EHT quan sát 2017, tái dựng vô tuyến, công bố 2022 | EHT Collaboration |
| M87* | EHT quan sát 2017, tái dựng vô tuyến, công bố 2019 | EHT Collaboration |

Link trang tư liệu và file ảnh nằm trong `imageSource` và `image`. Ảnh hiện tải từ máy chủ nguồn, không kèm bản sao cục bộ. Điều kiện sử dụng nguồn vẫn áp dụng; không coi mọi ảnh trên NASA/ESO là thuộc phạm vi công cộng.

Tất cả Canvas, quỹ đạo, điểm sao nền, bề mặt hành tinh và ảnh dự phòng là **minh họa nghệ thuật của ứng dụng**. Không phải dữ liệu Gaia, bản đồ bề mặt chính xác, ray tracing tương đối tính hay vị trí thời gian thực. Cảnh hố đen không mô phỏng vật lý; ảnh EHT riêng mới là tái dựng từ quan sát.

## Thêm dữ liệu
1. Đọc nguồn gốc và kiểm tra đối tượng được xác nhận.
2. Ghi giá trị, đơn vị, định nghĩa (trung bình/xích đạo), sai số khi cần và tham chiếu.
3. Không trộn giá trị từ nhiều nghiên cứu thành một kết quả mới.
4. Xác định ảnh, tác giả, bước sóng, gán màu/tái dựng và điều kiện sử dụng.
5. Cập nhật ngày biên tập thật, chạy kiểm tra và ghi giới hạn còn lại.
