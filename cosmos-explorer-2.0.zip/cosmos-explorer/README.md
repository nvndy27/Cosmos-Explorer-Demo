# Cosmos Explorer 2.0

Ứng dụng thiên văn tiếng Việt chạy tĩnh. Mở **index.html** bằng Chrome, Edge hoặc Firefox; không cần cài Node hay nhập API key. Giữ các tệp trong cùng thư mục.

## Sử dụng
- Chọn một trong 7 nhóm hoặc tìm toàn bộ 21 hồ sơ bằng tên có/không dấu. Enter mở kết quả đầu.
- Kéo để dịch góc nhìn, cuộn hoặc nút +/− để thu phóng; nút đặt lại đưa cảnh về ban đầu. Đồ họa là minh họa 2.5D, không theo tỷ lệ thật.
- Ảnh quan sát được ưu tiên khi chọn Orion, M51, Sagittarius A* hoặc M87*. Các ảnh có chú thích xử lý màu hoặc tái dựng dữ liệu và liên kết tư liệu gốc. Những mục còn lại mở nguồn chính thức để xem thêm.
- Đọc hai tab Tổng quan/Khám phá khoa học; mỗi thông số có link nguồn, hồ sơ có mục Nguồn khoa học và bài báo liên quan.
- Bấm ☆ để lưu cục bộ; “Đã lưu” lọc danh sách trong nhóm hiện tại.
- So sánh bán kính với Trái Đất chỉ khả dụng khi có tỷ lệ bán kính đã biên tập.
- Sao chép URL có #id để mở lại hồ sơ. Phím / tìm kiếm, mũi tên trái/phải chuyển hồ sơ, Esc đóng hướng dẫn hoặc tìm kiếm.

## Dữ liệu
21 mục: 8 hành tinh, Mặt Trăng, Diêm Vương, Mặt Trời, Proxima Centauri, TRAPPIST-1e, Ngân Hà, Andromeda, M51, Orion, Con Cua, Sgr A*, M87* và SMACS 0723/trường sâu Webb (một trường quan sát, không phải một thiên thể riêng).

Dữ liệu biên tập ngày 2026-10-21 từ NASA Science, ESA Gaia, NASA Exoplanet Archive, ESO/EHT và nghiên cứu được dẫn trong hồ sơ. Không có API cập nhật tự động hoặc tập sao Gaia thô. Không khẳng định khí quyển, nước hoặc sự sống đã được phát hiện ở TRAPPIST-1e.

Nội dung và mô hình vẫn dùng được khi mất mạng. Ảnh quan sát và phông Google tải trực tuyến; ảnh lỗi chuyển sang minh họa đúng nhãn, phông có dự phòng hệ thống.

## Kiểm tra
Nếu có Node.js, chạy từ thư mục dự án cha:

```bash
rtk proxy node --check cosmos-explorer/catalog.js
rtk proxy node --check cosmos-explorer/app.js
rtk proxy node cosmos-explorer/tests/smoke.cjs
```

Smoke hiện gồm 10 nhóm kiểm tra hành vi, dùng DOM/Canvas giả; không xác nhận bố cục hoặc tải ảnh mạng thật. Chưa có bộ e2e trình duyệt. Xem `../docs/QA.md` cho kết quả và checklist kiểm tra trực quan.

Tài liệu phát triển nằm ở `../docs/REQUIREMENTS.md`, `../docs/ROADMAP.md`, `../docs/DATA_POLICY.md` và `../AGENTS.md`.
