# Cosmos Explorer 2.2

Mở [cosmos-explorer/index.html](cosmos-explorer/index.html) trực tiếp bằng trình duyệt. Không cần máy chủ, framework, tài khoản hoặc API key.

138 hồ sơ (thêm 30), 126 hình ảnh cục bộ. Ba chế độ **Sơ đồ / Thư viện / So sánh**, hồ sơ đọc rộng và bốn bộ sưu tập. Chọn hành tinh luôn giữ tổng thể Hệ Mặt Trời; ảnh chi tiết nằm ở hồ sơ bên phải hoặc bên dưới trên mobile.

[Hướng dẫn](cosmos-explorer/README.md) · [Requirements](docs/REQUIREMENTS.md) · [Roadmap](docs/ROADMAP.md) · [Dữ liệu và nguồn](docs/DATA_POLICY.md) · [Kiểm tra](docs/QA.md) · [Kiểm kê ID và hồ sơ mới](docs/inventory-2.2.json)
