# Roadmap

## Bản 2.0 — đã triển khai
- [x] Tách dữ liệu và nguồn khỏi logic giao diện.
- [x] Mở rộng từ 9 lên 21 hồ sơ, bổ sung tinh vân và hố đen.
- [x] Tra cứu NASA, NASA Exoplanet Archive, ESA Gaia DR3 và các bài báo liên quan.
- [x] Bổ sung hình minh họa hố đen, tinh vân và màu riêng cho các hành tinh.
- [x] Chế độ ảnh quan sát cho 4 mục, ghi công và giới hạn ảnh.
- [x] Nguồn cho thông số, nghiên cứu và ngày biên tập.
- [x] Giao diện responsive, tìm không dấu, lọc đã lưu và URL hồ sơ.
- [x] Xử lý ảnh lỗi, bộ nhớ hỏng, reduced motion, focus hộp thoại.
- [x] 10 nhóm kiểm tra hành vi bằng Node không cần dependency.

## Bản 2.1 — đã triển khai
- [x] 108 hồ sơ: 10 Hệ Mặt Trời, 10 sao, 21 ngoại hành tinh, 40 thiên hà, 13 cụm sao, 10 tinh vân, 2 hố đen, Ngân Hà và trường sâu Webb.
- [x] Sơ đồ Hệ Mặt Trời giữ tổng thể khi chọn Trái Đất; ảnh chi tiết chỉ ở hồ sơ bên phải/bên dưới.
- [x] 78 ảnh quan sát lưu cục bộ, bao gồm ảnh hành tinh, Mặt Trời, Proxima, Hubble/Messier, EHT và Webb.
- [x] Minh họa sao phát sáng có quầng và bề mặt hạt; hình dạng khác nhau cho cụm sao, thiên hà, tinh vân và hố đen.
- [x] Snapshot nguồn NASA và truy vấn PS, ghi công và hash ảnh để truy vết.
- [x] Kiểm tra Chrome thực ở 390, 820 và 1440 px; ảnh cục bộ, lỗi ảnh, bàn phím và reduced motion. Xem QA.md.
- [x] Mở trực tiếp bằng file://, không cần máy chủ.

## Kiểm chứng bổ sung
- [ ] Rà soát bằng trình đọc màn hình và Firefox/Safari thực.

## 2.2 — chất lượng biên tập
- Mở rộng thêm các sao sáng quen thuộc với phép đo, sai số và tham chiếu gốc.
- Dịch thêm ghi chú quan sát cho từng đối tượng; giữ trích đoạn tiếng Anh có nguồn riêng.
- Thêm kiểm tra định kỳ về liên kết, giấy phép và phiên bản số liệu.

## 3.0 — bản đồ đo đạc
- Tập con Gaia DR3 có source_id, parallax/error và proper motion; tách vị trí đo khỏi hiệu ứng nền.
- Chỉ thêm bản đồ 3D/WebGL sau khi có kiểm chứng phép biến đổi tọa độ và fallback hiệu năng.
- Các giai đoạn 2.2/3.0 chưa được triển khai trong bản này.
