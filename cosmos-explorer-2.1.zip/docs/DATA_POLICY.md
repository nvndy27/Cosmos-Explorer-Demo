# Dữ liệu và tư liệu khoa học

Ngày biên tập: 2026-10-21. `cosmos-explorer/catalog.js` và `catalog-expanded.js` là dữ liệu chạy của ứng dụng. `catalog-expanded.js` được dựng từ snapshot trong `cosmos-explorer/data/`. Trường `source` áp dụng cho hồ sơ và thông số; `references` và `papers` bổ sung nguồn quan sát/nghiên cứu; `reviewed` ghi ngày biên tập. Đây là bản ghi tuyển chọn, không tự cập nhật.

## Nguồn
- Hệ Mặt Trời: NASA Science, trang Facts theo từng đối tượng. Số liệu làm tròn; không dùng số vệ tinh hay thông số chưa kiểm chứng mới.
- TRAPPIST-1e: [NASA Exoplanet Archive](https://exoplanetarchive.ipac.caltech.edu/overview/TRAPPIST-1e), [NASA về Webb 2025](https://science.nasa.gov/missions/webb/nasa-webb-looks-at-earth-sized-habitable-zone-exoplanet-trappist-1-e/), [Gillon 2017](https://doi.org/10.1038/nature21360), [DREAMS 2025](https://arxiv.org/abs/2509.05414). Không khẳng định phát hiện sự sống, nước hay khí quyển. Trang Archive qua công cụ mở trực tiếp bị timeout; kết quả tìm kiếm Archive xác nhận chu kỳ ~6,1 ngày, bán kính ~0,92 Trái Đất và xác nhận quá cảnh năm 2017.
- Ngân Hà: [ESA Gaia](https://www.esa.int/Science_Exploration/Space_Science/Gaia), [nội dung DR3](https://www.cosmos.esa.int/web/gaia/dr3), [Gaia Collaboration 2023](https://doi.org/10.1051/0004-6361/202243940). 1,806 tỷ là số nguồn có độ sáng G trong DR3, không phải số ngôi sao ứng dụng dựng hoặc tổng số sao Ngân Hà. Trang Cosmos chặn truy cập trực tiếp qua công cụ (451), tóm tắt tìm kiếm nguồn chính thức được dùng để đối chiếu.
- M42, M1, M51: danh mục Hubble Messier của NASA.
- Sgr A*, M87*: ESO/EHT và bài báo EHT 2022/2019 được liên kết trong từng hồ sơ.

## Phân loại ảnh
| Mục | Tư liệu | Ghi công |
|---|---|---|
| orion | Ảnh quan sát Hubble tổng hợp qua bộ lọc; màu hiển thị có xử lý khoa học. | NASA, ESA, M. Robberto (Space Telescope Science Institute/ESA) and the Hubble Space Telescope Orion Treasury Project Team |
| whirlpool | Ảnh quan sát Hubble tổng hợp qua bộ lọc; màu hiển thị có xử lý khoa học. | NASA, ESA, S. Beckwith (STScI) and the Hubble Heritage Team (STScI/AURA) |
| sgr | Ảnh EHT tái dựng từ dữ liệu vô tuyến, gán màu cường độ; không phải ảnh ánh sáng khả kiến. | EHT Collaboration |
| m87 | Ảnh EHT tái dựng từ dữ liệu vô tuyến, gán màu cường độ; không phải ảnh ánh sáng khả kiến. | EHT Collaboration |
| deep | Webb/NIRCam: quan sát hồng ngoại, tổng hợp qua bộ lọc và gán màu; đây là trường ảnh gồm các thiên hà ở nhiều khoảng cách. | NASA, ESA, CSA, STScI |

Link trang tư liệu và file ảnh nằm trong `imageSource` và `image`. Bản 2.1 lưu 78 ảnh WebP cục bộ, tối đa 800×800 px; chỉ đổi kích thước/định dạng, không sinh thêm nội dung ảnh. `imageRemote` giữ URL tải nguồn. `data/image-manifest.json` lưu nguồn, tác giả, phân loại, chú thích và SHA-256 của mỗi ảnh. Điều kiện sử dụng nguồn vẫn áp dụng; không coi mọi ảnh trên NASA/ESO là thuộc phạm vi công cộng.

Tất cả Canvas, quỹ đạo, điểm sao nền, bề mặt hành tinh và ảnh dự phòng là **minh họa nghệ thuật của ứng dụng**. Không phải dữ liệu Gaia, bản đồ bề mặt chính xác, ray tracing tương đối tính hay vị trí thời gian thực. Cảnh hố đen không mô phỏng vật lý; ảnh EHT riêng mới là tái dựng từ quan sát.

## Thêm dữ liệu
1. Đọc nguồn gốc và kiểm tra đối tượng được xác nhận.
2. Ghi giá trị, đơn vị, định nghĩa (trung bình/xích đạo), sai số khi cần và tham chiếu.
3. Không trộn giá trị từ nhiều nghiên cứu thành một kết quả mới.
4. Xác định ảnh, tác giả, bước sóng, gán màu/tái dựng và điều kiện sử dụng.
5. Cập nhật ngày biên tập thật, chạy kiểm tra và ghi giới hạn còn lại.

## Snapshot bản 2.1
- `data/messier-snapshot.json`: 59 hồ sơ NASA Hubble Messier, gồm khoảng cách, cấp sao biểu kiến, chòm sao, loại thiên thể, ngày lấy, hash trang, nguồn ảnh và ghi công. Các trang được đọc/tách trường theo cấu trúc nguồn; không tự điền trường thiếu. Danh sách chọn và nguồn gốc được lưu trong cùng file. Trích đoạn ghi chú ảnh tối đa 45 từ, hiển thị nguyên văn, không giả là bản dịch.
- `data/exoplanet-snapshot.json`: truy vấn và 20 dòng từ bảng Planetary Systems (`ps`) của NASA Exoplanet Archive, chỉ bộ mặc định `default_flag=1`, cờ tranh luận `pl_controv_flag=0`; có bán kính, chu kỳ, khoảng cách và các thông số sao đã dùng. Các giá trị thuộc cùng dòng PS, không ghép từ bảng composite. Truy vấn đầy đủ và URL TAP được lưu để tái tạo.
- `data/exoplanet-records.json`: 20 hồ sơ hành tinh và 8 hồ sơ sao chủ được biên tập từ snapshot trên. Không suy ra thành phần, bề mặt, khí quyển hoặc khả năng có sự sống từ bán kính. Sai số cần tra tại Archive và bài báo gốc; snapshot chỉ chứa các cột đã truy vấn.
- pc là parsec; R⊕ là bán kính Trái Đất, R☉ là bán kính Mặt Trời, K là kelvin. Cấp sao biểu kiến không phải độ sáng tuyệt đối. Không dùng thông số sao làm bán kính hành tinh.
- Các nguồn mới được lấy trực tiếp qua HTTPS thành công trong phiên này. Những hạn chế truy cập Archive/Cosmos ghi ở mục cũ là lịch sử đối chiếu bản 2.0, không phải trạng thái của lần lấy PS bản 2.1.

## Phân biệt tư liệu bổ sung
- Trái Đất: Blue Marble 2007 tổng hợp dữ liệu vệ tinh, không phải một lần chụp duy nhất.
- Mặt Trời: SDO/AIA 304 cực tím được gán màu.
- Proxima: ảnh Hubble của điểm sáng và nhiễu xạ, không phải ảnh phân giải bề mặt.
- Webb/SMACS 0723: ảnh trường quan sát hồng ngoại tổng hợp và gán màu.
- Mỗi ảnh hành tinh có tàu quan sát và ghi chú xử lý riêng trong hồ sơ.
- Minh họa cho các sao chủ và ngoại hành tinh do ứng dụng vẽ, không phải ảnh quan sát. Quầng sáng/màu/bề mặt chỉ minh họa.

## Tái tạo
Công cụ biên tập trong `scripts/` cần Python, beautifulsoup4 và Pillow; ứng dụng chạy không cần các thư viện này. `refresh_catalog.py` đọc lại các trang Messier và ảnh; `refresh_exoplanets.py --fetch` lấy lại truy vấn PS đã lưu; bỏ `--fetch` để biên tập từ snapshot hiện có. Sau khi duyệt thay đổi, chạy `build_catalog.py`. `cache_images.py` phục hồi các ảnh cục bộ bị thiếu từ manifest. Không coi dữ liệu nguồn thay đổi là thay đổi đã được duyệt tự động.
