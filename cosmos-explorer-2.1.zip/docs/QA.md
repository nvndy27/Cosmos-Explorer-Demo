# Kiểm chứng bản 2.1

Ngày chạy: 2026-10-21.

## Đã đạt
- Kiểm tra cú pháp bốn tệp JavaScript chạy của ứng dụng bằng Node.
- 11 nhóm smoke không cần dependency: 108 hồ sơ/9 nhóm, nguồn và ghi công, chọn/vẽ, tìm không dấu/rỗng, lưu/lọc/rỗng, so sánh bán kính, hồi quy Trái Đất nhỏ và ảnh chỉ ở hồ sơ, ID duy nhất và tài nguyên ảnh, tạm dừng, bộ nhớ hỏng/reduced motion, tab ARIA.
- Chrome headless thực qua Playwright tạm trong /tmp; không thêm dependency/build vào ứng dụng. Không có lỗi JavaScript chưa xử lý trong các lượt kiểm tra.
- 108 hồ sơ được mở và vẽ trong trình duyệt, 9 nhóm điều hướng hoạt động.
- Cả 78 ảnh cục bộ giải mã thành công. Chặn ảnh Trái Đất thật bằng network route để kiểm tra Canvas dự phòng và nhãn minh họa.
- 390, 820 và 1440 px: chụp và xem ảnh kết quả, trang không tràn ngang.
- Chọn Trái Đất giữ tiêu đề “Hệ Mặt Trời”, bán kính hình Trái Đất trong sơ đồ mặc định dưới 10 CSS px; không có ảnh toàn khung giữa.
- Nhấp thiên thể trên Canvas, tìm “sao thuy” + Enter, lưu/tải lại/lọc, chuyển tab.
- Hộp hướng dẫn: focus ban đầu, Shift+Tab giữ trong hộp, Escape trả focus.
- Reduced motion mặc định dừng; localStorage chứa dữ liệu hỏng không làm ứng dụng lỗi.
- Nội dung tiếp tục đổi hồ sơ khi context ở chế độ offline.
- Mở trực tiếp bằng file://: 108 hồ sơ nạp được, chọn Trái Đất, ảnh địa phương tải thành công, không có lỗi JavaScript.

## Bằng chứng
- [Ảnh 1440 px](qa/earth-1440.png)
- [Ảnh 820 px](qa/earth-820.png)
- [Ảnh 390 px](qa/earth-390.png)
- [Báo cáo browser dạng JSON](qa/browser-report.json)

## Giới hạn
Chưa xác nhận Firefox/Safari hoặc trình đọc màn hình thật. Chrome headless kiểm tra hành vi/ảnh, không thay thế kiểm định thiên văn độc lập hay kiểm toán tiếp cận đầy đủ. Các bài báo và link nguồn ngoài được lưu để người dùng tra cứu; không có cam kết mọi link ngoài luôn khả dụng.

## Chạy lại smoke
```bash
rtk proxy node --check cosmos-explorer/catalog.js
rtk proxy node --check cosmos-explorer/catalog-expanded.js
rtk proxy node --check cosmos-explorer/scene.js
rtk proxy node --check cosmos-explorer/app.js
rtk proxy node cosmos-explorer/tests/smoke.cjs
```

Browser QA dùng Playwright cài tạm bên ngoài repo và Chrome hệ thống. Dự án giữ nguyên cách chạy tĩnh, chưa thiết lập pipeline browser CI.
