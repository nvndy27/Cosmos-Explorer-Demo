# Cosmos Explorer 2.1

Mở [cosmos-explorer/index.html](cosmos-explorer/index.html) bằng trình duyệt. 108 hồ sơ, 78 ảnh lưu cục bộ, không cần cài đặt hoặc máy chủ.

Chọn Trái Đất giữ góc nhìn tổng thể Hệ Mặt Trời. Ảnh chi tiết chỉ nằm trong hồ sơ bên phải/bên dưới.

[Hướng dẫn](cosmos-explorer/README.md) · [Requirements](docs/REQUIREMENTS.md) · [Roadmap](docs/ROADMAP.md) · [Dữ liệu và nguồn](docs/DATA_POLICY.md) · [Kiểm thử](docs/QA.md)
