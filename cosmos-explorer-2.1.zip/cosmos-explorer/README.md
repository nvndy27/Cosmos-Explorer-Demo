# Cosmos Explorer 2.1

Mở **index.html** bằng Chrome, Edge hoặc Firefox; giữ nguyên các tệp và thư mục đi kèm. Không cần cài đặt, API key hoặc máy chủ. Đã kiểm tra mở trực tiếp bằng file:// trong Chrome.

## Khám phá
- 108 hồ sơ thuộc 9 nhóm: 10 đối tượng Hệ Mặt Trời, 10 sao, 21 ngoại hành tinh, 40 thiên hà, 13 cụm sao, 10 tinh vân, 2 hố đen, Ngân Hà và trường quan sát SMACS 0723.
- Khung giữa là sơ đồ tổng quan. Chọn Trái Đất hoặc hành tinh khác giữ nguyên tổng thể Hệ Mặt Trời; ảnh chi tiết chỉ nằm trong hồ sơ bên phải, hoặc bên dưới trên điện thoại.
- 78 ảnh quan sát được lưu cục bộ: hành tinh, Mặt Trăng, Diêm Vương, Mặt Trời, Proxima, Hubble/Messier, EHT và Webb. Ảnh có ghi công, nguồn và chú thích xử lý màu/tái dựng.
- Minh họa cho sao chủ và ngoại hành tinh chưa có ảnh trực tiếp được ghi rõ. Sao, cụm sao, thiên hà, tinh vân và hố đen có cách vẽ riêng.
- Chọn nhãn hoặc thiên thể trên sơ đồ để mở hồ sơ; kéo để dịch góc nhìn, cuộn hoặc +/− để thu phóng. Sơ đồ nén riêng kích thước/khoảng cách và không phải vị trí thời gian thực.
- Tìm toàn danh mục bằng tên có/không dấu, tên Messier hoặc tên tiếng Anh; Enter mở kết quả đầu tiên.
- ☆ lưu cục bộ. “Đã lưu” lọc trong nhóm hiện tại. So sánh chỉ áp dụng khi có dữ liệu bán kính phù hợp.
- URL #id mở lại hồ sơ; / tìm kiếm; mũi tên trái/phải chuyển mục; Esc đóng hướng dẫn/tìm kiếm.

## Dữ liệu và giới hạn
Snapshot ngày 2026-10-21 từ NASA Science/Hubble, ESA Gaia, NASA Exoplanet Archive và ESO/EHT. 59 hồ sơ Messier mới được tách từ trang nguồn; 20 ngoại hành tinh và 8 sao chủ được lấy từ cùng dòng bộ tham số mặc định trong bảng PS. Không tự đồng bộ số liệu khi mở ứng dụng.

Mỗi thông số có nguồn; hồ sơ có giới hạn quan sát và nghiên cứu liên quan khi đã tích hợp. Có bản dữ liệu, truy vấn, ngày lấy, tác giả và hash ảnh trong `data/`. Trích đoạn tiếng Anh từ NASA được ghi rõ nguyên văn.

Tất cả điểm/vị trí, quỹ đạo và Canvas là minh họa, không phải tọa độ Gaia, bản đồ bề mặt chính xác hay mô phỏng vật lý. Không suy ra khí quyển, nước hoặc sự sống từ bán kính/vùng có thể có nước lỏng.

Nội dung, đồ họa và ảnh dùng được không mạng; Google Fonts có phông hệ thống dự phòng. Liên kết nguồn ngoài cần Internet.

## Kiểm tra
Từ thư mục dự án cha:

```bash
rtk proxy node --check cosmos-explorer/catalog.js
rtk proxy node --check cosmos-explorer/catalog-expanded.js
rtk proxy node --check cosmos-explorer/scene.js
rtk proxy node --check cosmos-explorer/app.js
rtk proxy node cosmos-explorer/tests/smoke.cjs
```

11 nhóm smoke dùng DOM/Canvas giả. Kiểm tra Chrome thực và ảnh chụp ở 390, 820, 1440 px được ghi tại `../docs/QA.md`. Công cụ biên tập Python ở `../scripts/` là tùy chọn, không phải phụ thuộc để sử dụng ứng dụng.

Tài liệu: `../docs/REQUIREMENTS.md`, `../docs/ROADMAP.md`, `../docs/DATA_POLICY.md`, `../AGENTS.md`.
